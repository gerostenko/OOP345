///OOP345 Workshop 1: From One Translation Unit to Another 
// File: process.h
// Version: 1.0
// Date: 2017/09/09
// Author: Galina Erostenko
// Description: Process function header
///////////////////////////////////////////////////
#ifndef PROCESS_H__
#define PROCESS_H__

void process(const char* string);

#endif